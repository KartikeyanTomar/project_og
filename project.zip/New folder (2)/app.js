const express = require('express');
const mongoose = require('mongoose');
const methodOverride = require('method-override');
const employeeRoutes = require('./routes/employeeRoutes');

// Create Express app
const app = express();

// Connect to MongoDB database
mongoose.connect('mongodb://localhost:27017/employee-management', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('Connected to MongoDB successfully'))
.catch(err => console.error('MongoDB connection error:', err));

// Set up middleware
// 1. Set view engine to EJS for templates
app.set('view engine', 'ejs');
// 2. Parse form data
app.use(express.urlencoded({ extended: true }));
// 3. Enable PUT and DELETE requests
app.use(methodOverride('_method'));
// 4. Serve static files from 'public' folder
app.use(express.static('public'));

// Use employee routes
app.use('/', employeeRoutes);

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
}); 