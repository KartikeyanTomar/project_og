const express = require('express');
const router = express.Router();
const Employee = require('../models/employee');

// 1. DISPLAY ALL EMPLOYEES
// GET /employees
router.get('/employees', async (req, res) => {
    try {
        // Get all employees from database
        const employees = await Employee.find({});
        // Display them using the index template
        res.render('employees/index', { employees });
    } catch (err) {
        // If there's an error, show it
        res.status(500).send('Error loading employees: ' + err.message);
    }
});

// 2. SHOW FORM TO CREATE NEW EMPLOYEE
// GET /employee/new
router.get('/employee/new', (req, res) => {
    res.render('employees/new');
});

// 3. CREATE NEW EMPLOYEE
// POST /employees
router.post('/employees', async (req, res) => {
    try {
        // Create new employee using form data (req.body)
        const employee = new Employee(req.body);
        await employee.save();
        // Redirect to employees list after creating
        res.redirect('/employees');
    } catch (err) {
        // If there's an error, show the form again with error message
        res.render('employees/new', { error: err.message });
    }
});

// 4. SHOW SINGLE EMPLOYEE DETAILS
// GET /employees/:id
router.get('/employees/:id', async (req, res) => {
    try {
        // Find employee by ID
        const employee = await Employee.findById(req.params.id);
        if (!employee) {
            return res.status(404).send('Employee not found');
        }
        // Show employee details
        res.render('employees/show', { employee });
    } catch (err) {
        res.status(404).send('Employee not found');
    }
});

// 5. SHOW EDIT FORM
// GET /employees/:id/edit
router.get('/employees/:id/edit', async (req, res) => {
    try {
        const employee = await Employee.findById(req.params.id);
        if (!employee) {
            return res.status(404).send('Employee not found');
        }
        res.render('employees/edit', { employee });
    } catch (err) {
        res.status(404).send('Employee not found');
    }
});

// 6. UPDATE EMPLOYEE
// PUT /employees/:id
router.put('/employees/:id', async (req, res) => {
    try {
        // Remove employeeName from update data (since it can't be changed)
        const { employeeName, ...updateData } = req.body;
        // Update employee with new data
        await Employee.findByIdAndUpdate(req.params.id, updateData);
        // Redirect to employee details page
        res.redirect(`/employees/${req.params.id}`);
    } catch (err) {
        res.status(400).send('Error updating employee: ' + err.message);
    }
});

// 7. DELETE EMPLOYEE
// DELETE /employees/:id
router.delete('/employees/:id', async (req, res) => {
    try {
        await Employee.findByIdAndDelete(req.params.id);
        // Redirect to employees list after deleting
        res.redirect('/employees');
    } catch (err) {
        res.status(500).send('Error deleting employee: ' + err.message);
    }
});

module.exports = router; 