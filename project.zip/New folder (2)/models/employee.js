const mongoose = require('mongoose');

// Define the structure for an Employee
const employeeSchema = new mongoose.Schema({
    // Employee's full name - required field that will be trimmed (remove extra spaces)
    employeeName: {
        type: String,
        required: true,
        trim: true
    },
    // Employee's salary - must be a number
    salary: {
        type: Number,
        required: true
    },
    // URL for employee's image
    image: {
        type: String,
        required: true
    },
    // Employee's job role (e.g., "Developer", "Manager")
    role: {
        type: String,
        required: true
    },
    // Name of the company where employee works
    companyName: {
        type: String,
        required: true
    }
});

// Create and export the Employee model
module.exports = mongoose.model('Employee', employeeSchema); 